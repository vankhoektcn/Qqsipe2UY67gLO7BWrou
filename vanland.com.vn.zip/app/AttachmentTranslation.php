<?php

namespace App;

class AttachmentTranslation extends BaseModel
{
	protected $table = "attachment_translations";
	public $timestamps = false;
}
